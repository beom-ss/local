#3.18
co<-factor(c(1,2,3,4))
obs<-factor(c(1,2,3,4))
dat_3.18<-expand.grid(tre=co,obs=obs)
c_3.18<-c(143,152,134,129,141,149,136,127,150,137,132,132,146,143,127,129)
dat_3.18<-cbind(dat_3.18,c_3.18)
#(a~d)
#fitting
fit_3.18<-aov(c_3.18~tre,data=dat_3.18)
summary(fit_3.18)
lsd_3.18<-LSD.test(fit_3.18,"tre",group=F)
#(e)
boxplot(c_3.18~tre,data=dat_3.18,xlab="Coding",ylab="conductivity",main="Coding vs conductivity")

#3.19
plot(fit_3.18)


#3.27
che<-factor(c(1,2,3,4))
o_3.27<-factor(c(1,2,3))
dat_3.27<-expand.grid(tre=che,obs=o_3.27)
c_3.27<-c(84.99,85.15,84.72,84.20,84.04,85.13,84.48,84.10,84.38,84.88,85.16,84.55)
dat_3.27<-cbind(dat_3.27,c_3.27)
#fittting
fit_3.27<-aov(c_3.27~tre,data=dat_3.27)
#(a)
summary(fit_3.27)
#(b)
plot(fit_3.27)
#(c)
contrasmatrix<-cbind(c(1,-3,1,1),c(-2,0,1,1),c(0,0,-1,1))
contrasts(dat_3.27$tre)<-contrasmatrix
# result for t-value anova
summary.lm(aov(c_3.27~tre,data=dat_3.27))

#3.31
bun<-factor(c(1,2,3,4,5))
o_3.31<-factor(c(1,2,3,4,5))
dat_3.31<-expand.grid(tre=bun,obs=o_3.31)
c_3.31<-c(23.46,23.59,23.51,23.28,23.29,23.48,23.46,23.64,23.40,23.46,23.56,23.42,23.46,23.37,23.37,23.39,23.49,23.52,23.46,23.32,23.40,23.50,23.49,23.39,23.38)
dat_3.31<-cbind(dat_3.31,c_3.31)
#fittting
fit_3.31<-aov(c_3.31~tre,data=dat_3.31)
summary(fit_3.31)
plot(fit_3.31)

#4.11
MP<-factor(c("MP","MP+HD","MP+LD"))
block<-factor(seq(1:10))
dat_4.11<-expand.grid(tre=MP,block=block)
c_4.11<-c(334.5,919.4,108.4,31.6,404.2,26.1,701,1024.8,240.8,41.2,54.1,191.1,61.2,62.8,69.7,69.6,671.6,242.8,67.5,882.1,62.7,66.6,354.2,396.9,120.7,321.9,23.6,881.9,91.1,290.4)
dat_4.11<-cbind(dat_4.11,c_4.11)
# fitting anova
fit_4.11<-aov(c_4.11~tre+block,data=dat_4.11)
summary(fit_4.11)
lsd_4.1<-LSD.test(fit_4.1,"PSI",group=F)
# Model Adequacy Checking 
par(mfrow=c(2,2))
plot(fit_4.11)
fit_4.11_2<-aov(log(c_4.11)~tre+block,data=dat_4.11)
summary(fit_4.11_2)
plot(fit_4.11_2)
